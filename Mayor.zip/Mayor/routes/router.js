const express = require('express');
const david = express.Router();
const pastrana = require('../controller/PastranaController');
david.get('/', pastrana.main);
david.get('/moises', pastrana.moises);
david.get('/atienza', pastrana.atienza);
david.get('/faith', pastrana.faith);
david.get('/mayor', pastrana.mayor);
module.exports = david;