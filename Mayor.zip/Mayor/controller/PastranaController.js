const m = {
    main:(req, res) =>{
        res.render('index');
    },
    moises:(req, res) =>{
        res.render('index');
    },
    atienza:(req, res) =>{
        res.render('index');

    },
    faith:(req, res) =>{
        res.render('index');

    },
    mayor:(req, res) =>{
        res.render('index');

    }

};

module.exports = m;